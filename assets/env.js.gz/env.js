// this is really just separate because we can't include it above other includes otherwise
var STS = { events: {} };
